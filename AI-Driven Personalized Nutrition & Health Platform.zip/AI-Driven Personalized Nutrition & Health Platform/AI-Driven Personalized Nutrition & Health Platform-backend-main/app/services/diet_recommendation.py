import joblib
import random

# Load pre-trained model (Dummy for now)
try:
    model = joblib.load('ml_models/recommendation_model.pkl')
except:
    model = None

# Dummy fallback function
def recommend_meals(user_data):
    if model:
        features = [user_data['age'], user_data['weight'], user_data['height'], user_data['bmi']]
        recommendations = model.predict([features])
        return {"recommendations": recommendations.tolist()}
    else:
        # Dummy recommendation without model
        sample_meals = [
            {"meal": "Grilled Chicken Salad", "calories": 300},
            {"meal": "Quinoa Veggie Bowl", "calories": 350},
            {"meal": "Low-carb Zucchini Pasta", "calories": 250}
        ]
        return {"recommendations": random.sample(sample_meals, 2)}
