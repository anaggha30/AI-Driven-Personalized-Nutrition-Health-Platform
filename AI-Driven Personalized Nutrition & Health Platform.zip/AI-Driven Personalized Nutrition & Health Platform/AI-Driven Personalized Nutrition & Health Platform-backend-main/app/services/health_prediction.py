import joblib

try:
    health_model = joblib.load('models/health_risk_model.pkl')
except:
    health_model = None

def predict_health_risk(user_data):
    if health_model:
        features = [user_data['age'], user_data['weight'], user_data['height'], user_data['bmi']]
        risk = health_model.predict([features])
        return {"health_risk": risk.tolist()}
    else:
        return {"health_risk": "Model not available"}
