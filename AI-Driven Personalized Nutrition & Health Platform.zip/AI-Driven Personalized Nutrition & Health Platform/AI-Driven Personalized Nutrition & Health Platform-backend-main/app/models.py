from .database import db
from datetime import datetime

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # One-to-one relationship
    health_profile = db.relationship('HealthProfile', back_populates='user', uselist=False)

class HealthProfile(db.Model):
    __tablename__ = 'health_profile'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False)  # FK to user
    age = db.Column(db.Integer)
    weight = db.Column(db.Float)
    height = db.Column(db.Float)
    conditions = db.Column(db.String)
    allergies = db.Column(db.String)

    user = db.relationship('User', back_populates='health_profile')

class MealPlan(db.Model):
    __tablename__ = 'meal_plan'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plan_data = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class BmiHistory(db.Model):
    __tablename__ = 'bmi_history'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Corrected FK
    date = db.Column(db.Date, nullable=False)
    bmi = db.Column(db.Float, nullable=False)
    user = db.relationship('User', backref=db.backref('bmi_history', lazy=True))

    def __repr__(self):
        return f"<BmiHistory(user_id={self.user_id}, date={self.date}, bmi={self.bmi})>"
    
class WeeklyIntake(db.Model):
    __tablename__ = 'weekly_intake'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # Corrected FK
    week = db.Column(db.String(50), nullable=False)
    carbs = db.Column(db.Integer, nullable=False)
    protein = db.Column(db.Integer, nullable=False)
    calories = db.Column(db.Integer, nullable=False)

    user = db.relationship('User', backref=db.backref('weekly_intake', lazy=True))

    def __repr__(self):
        return f"<WeeklyIntake(user_id={self.user_id}, week={self.week}, carbs={self.carbs}, protein={self.protein}, calories={self.calories})>"

    
class MacronutrientDistribution(db.Model):
    __tablename__ = 'macronutrient_distribution'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    value = db.Column(db.Float, nullable=False)

    user = db.relationship('User', backref=db.backref('macronutrient_distribution', lazy=True))

    def __repr__(self):
        return f"<MacronutrientDistribution(user_id={self.user_id}, name={self.name}, value={self.value})>"

