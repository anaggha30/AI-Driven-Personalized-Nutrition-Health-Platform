from flask import Blueprint, jsonify, request
from app.models import HealthProfile
from app.utils.chatwithme import generate_meal_plan_chat
from flask_jwt_extended import jwt_required, get_jwt_identity
from flask_cors import cross_origin
import logging

chat_bp = Blueprint('chat', __name__, url_prefix='/chat')
logger = logging.getLogger(__name__)

@chat_bp.route('', methods=['POST'])
@cross_origin()
@jwt_required()
def chat_with_ai():
    try:
        # Get the user_id from the JWT identity
        user_id = get_jwt_identity()
        logger.info(f"Initiating AI chat for user_id: {user_id}")

        # Query the health profile from the database based on user_id
        profile = HealthProfile.query.filter_by(user_id=user_id).first()

        # If the profile doesn't exist, return a warning message
        if not profile:
            logger.warning(f"No health profile found for user_id: {user_id}")
            return jsonify({"msg": "Create health profile first"}), 400

        data = request.get_json()
        # Generate the meal plan using the AI chat function
        meal_plan_chat = generate_meal_plan_chat(profile, data)

        # If the meal plan chat generation fails, return an error
        if not meal_plan_chat:
            logger.warning(f"Meal plan chat generation returned empty for user_id: {user_id}")
            return jsonify({"msg": "Could not generate meal plan chat"}), 500

        # Log success and return the meal plan chat as a response
        logger.info(f"Meal plan chat successfully generated for user_id: {user_id}")
        return jsonify(meal_plan_chat), 200

    except Exception as e:
        # Log any exceptions that occur during the process
        logger.exception(f"Error generating meal plan chat for user_id: {user_id}")
        return jsonify({"msg": f"Error: {str(e)}"}), 500
