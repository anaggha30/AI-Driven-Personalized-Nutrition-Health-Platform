from flask import Blueprint, request, jsonify
from ..models import User
from ..database import db

user_bp = Blueprint('user', __name__, url_prefix='/user')

@user_bp.route('/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({"message": "User not found"}), 404
    return jsonify({
        "id": user.id,
        "name": user.name,
        "email": user.email,
        "age": user.age,
        "weight": user.weight,
        "height": user.height,
        "bmi": user.bmi,
        "dietary_restrictions": user.dietary_restrictions
    })
