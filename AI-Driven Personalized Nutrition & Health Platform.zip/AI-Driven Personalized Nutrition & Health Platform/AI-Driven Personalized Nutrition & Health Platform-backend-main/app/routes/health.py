from flask import Blueprint, request, jsonify
from app.models import HealthProfile, User, BmiHistory, WeeklyIntake, MacronutrientDistribution
from app.database import db
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging
from datetime import datetime, timedelta
import random

health_bp = Blueprint('health', __name__)
logger = logging.getLogger(__name__)

@health_bp.route('/profile', methods=['POST'])
@jwt_required()
def create_or_update_profile():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()

        age = data.get('age')
        weight = data.get('weight')
        height = data.get('height')
        conditions = data.get('conditions')
        allergies = data.get('allergies')

        # Validation helper
        def validate_field(value, field_name):
            if isinstance(value, (int, float)):
                return value
            if isinstance(value, str) and value.strip().lower() in ['na', 'n/a', 'not', 'not applicable']:
                return value.strip()
            raise ValueError(f"{field_name} must be a number or a valid string (NA, Not Applicable)")

        try:
            validated_age = validate_field(age, 'Age')
            validated_weight = validate_field(weight, 'Weight')
            validated_height = validate_field(height, 'Height')
        except ValueError as ve:
            return jsonify({"msg": str(ve)}), 400

        # Process conditions
        if isinstance(conditions, list):
            conditions = ','.join([str(c).strip() for c in conditions])
        elif isinstance(conditions, str):
            conditions = conditions.strip()
        else:
            return jsonify({"msg": "Conditions must be a string or list"}), 422

        # Process allergies
        if isinstance(allergies, list):
            allergies = ','.join([str(a).strip() for a in allergies])
        elif isinstance(allergies, str):
            allergies = allergies.strip()
        else:
            return jsonify({"msg": "Allergies must be a string or list"}), 422

        # Create or update health profile
        profile = HealthProfile.query.filter_by(user_id=user_id).first()
        if not profile:
            profile = HealthProfile(user_id=user_id)

        profile.age = validated_age
        profile.weight = validated_weight
        profile.height = validated_height
        profile.conditions = conditions
        profile.allergies = allergies

        db.session.add(profile)
        db.session.commit()

        # Always insert MOCK history if missing
        if not BmiHistory.query.filter_by(user_id=user_id).first():
            if isinstance(validated_weight, (int, float)) and isinstance(validated_height, (int, float)):
                today = datetime.utcnow()
                base_weight = validated_weight

                for months_ago in range(6, 0, -1):
                    date_entry = today - timedelta(days=months_ago * 30)
                    # Small random weight change
                    weight_variation = random.uniform(-2, 2)  # -2kg to +2kg
                    monthly_weight = base_weight + weight_variation
                    bmi_value = round(monthly_weight / ((validated_height / 100) ** 2), 2)
                    bmi_entry = BmiHistory(
                        user_id=user_id,
                        bmi=bmi_value,
                        date=date_entry
                    )
                    db.session.add(bmi_entry)

        if not WeeklyIntake.query.filter_by(user_id=user_id).first():
            # Create mock weekly intake for past 6 weeks
            for week_num in range(1, 7):
                carbs = random.randint(150, 250)  # grams
                protein = random.randint(50, 100)  # grams
                fats = random.randint(40, 80)      # grams
                # Calculate rough calories (4 cal/g carbs, 4 cal/g protein, 9 cal/g fats)
                calories = carbs * 4 + protein * 4 + fats * 9
                weekly_entry = WeeklyIntake(
                    user_id=user_id,
                    week=f"Week {week_num}",
                    carbs=carbs,
                    protein=protein,
                    calories=calories
                )
                db.session.add(weekly_entry)

        if not MacronutrientDistribution.query.filter_by(user_id=user_id).first():
            # Mock balanced macros
            macros = [
                {"name": "Carbohydrates", "value": 50},  # 50%
                {"name": "Proteins", "value": 30},       # 30%
                {"name": "Fats", "value": 20},            # 20%
            ]
            for macro in macros:
                macro_entry = MacronutrientDistribution(
                    user_id=user_id,
                    name=macro['name'],
                    value=macro['value']
                )
                db.session.add(macro_entry)

        db.session.commit()

        return jsonify({"msg": "Profile updated successfully with mock history data."}), 200

    except Exception as e:
        logger.error(f"Error updating profile: {e}")
        return jsonify({"msg": f"Error: {str(e)}"}), 500

@health_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    try:
        user_id = get_jwt_identity()
        user = User.query.filter_by(id=user_id).first()

        if not user:
            return jsonify({"msg": "User not found"}), 404

        health_profile = user.health_profile
        if not health_profile:
            return jsonify({
                "msg": "Health profile not found, please complete your profile",
                "redirect_to": "/profile"
            }), 302

        # Fetch BMI History
        bmi_trend = BmiHistory.query.filter_by(user_id=user_id).order_by(BmiHistory.date.desc()).all()
        bmi_data = [{
            "id": entry.id,
            "date": entry.date.strftime('%Y-%m-%d'),
            "bmi": entry.bmi
        } for entry in bmi_trend]

        # Fetch Weekly Intake History
        weekly_intakes = WeeklyIntake.query.filter_by(user_id=user_id).order_by(WeeklyIntake.week).all()
        weekly_data = [{
            "id": entry.id,
            "week": entry.week,
            "carbs": entry.carbs,
            "protein": entry.protein,
            "calories": entry.calories
        } for entry in weekly_intakes]

        # Fetch Macronutrient Distribution
        macronutrient_data = MacronutrientDistribution.query.filter_by(user_id=user_id).all()
        macro_distribution = [{
            "id": entry.id,
            "name": entry.name,
            "value": entry.value
        } for entry in macronutrient_data]

        return jsonify({
            "profile": {
                "age": health_profile.age,
                "weight": health_profile.weight,
                "height": health_profile.height,
                "conditions": health_profile.conditions.split(',') if health_profile.conditions else [],
                "allergies": health_profile.allergies.split(',') if health_profile.allergies else [],
            },
            "history": {
                "bmi": bmi_data,
                "weeklyIntake": weekly_data,
                "macronutrients": macro_distribution
            }
        }), 200

    except Exception as e:
        logger.error(f"Error fetching profile: {e}")
        return jsonify({"msg": f"Error: {str(e)}"}), 500
