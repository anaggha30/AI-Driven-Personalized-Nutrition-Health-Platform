import google.generativeai as genai
import json
import re

# Configure your API key for Google Generative AI
genai.configure(api_key="AIzaSyCIqYQvLOVOqmSYvBnvmFkXlkOkqKLdy_c")

# Specify the model to use
model = genai.GenerativeModel(model_name="gemini-1.5-flash")
import json
import re

def generate_meal_plan_chat(profile, message):
    # Prepare user data
    conditions = [c.strip() for c in profile.conditions.split(',')] if profile.conditions else []
    allergies = [a.strip() for a in profile.allergies.split(',')] if profile.allergies else []

    # Create the simplified prompt
    prompt = f"""
    You are an AI assistant helping users with personalized meal plans. Here is the user's profile:

    - Health Conditions: {', '.join(conditions) if conditions else 'None'}
    - Allergies: {', '.join(allergies) if allergies else 'None'}

    The user asked: "{message}"

    Respond in a friendly, conversational style.
    Focus directly on answering the user's question, suggesting meals or advice based on their needs.
    
    Provide your response in this JSON format:
    {{
        "response": "Your conversational answer here, considering the user's profile and their request."
    }}
    Only return valid JSON — do not include explanations or any text outside the JSON.
    """

    # Generate content using the model
    response = model.generate_content(prompt)
    raw_output = response.text.strip()

    # Extract the JSON object safely
    match = re.search(r"```json\s*(.*?)\s*```", raw_output, re.DOTALL)
    json_text = match.group(1).strip() if match else raw_output

    try:
        chat_response = json.loads(json_text)
        return chat_response
    except json.JSONDecodeError as e:
        return {
            "error": "Failed to parse the model's response as JSON.",
            "raw_response": raw_output,
            "exception": str(e)
        }
