import google.generativeai as genai
import json
import re

genai.configure(api_key="AIzaSyCIqYQvLOVOqmSYvBnvmFkXlkOkqKLdy_c")

model = genai.GenerativeModel(model_name="gemini-1.5-flash")

def generate_meal_plan(profile):
    conditions = profile.conditions.split(',') if profile.conditions else []
    allergies = profile.allergies.split(',') if profile.allergies else []

    prompt = f"""
    You are a nutrition expert. Based on the following user profile, generate a daily personalized meal plan.
    
    Conditions: {', '.join(conditions) if conditions else 'None'}
    Allergies: {', '.join(allergies) if allergies else 'None'}

    Requirements:
    - Tailor meals to medical conditions and allergies.
    - Keep meals balanced and practical.
    - Provide calorie count per meal.
    - Respond in JSON format with:
      {{
          "daily_meals": [
              {{"meal": "Meal name", "calories": 000, "description": "brief text"}},
              ...
          ],
          "weekly_meals": [
                {{
                    "day": "Day of the week",
                    "meal_plan": [
                        {{
                            "meal": "Meal name",
                            "calories": 000,
                            "description": "Brief description"
                        }},
                        ...
                    ],
                    "total_day_calories": 000
                }},
        ...
    ],
          "total_calories": 000
      }}
    """

    response = model.generate_content(prompt)
    raw_output = response.text.strip()

    # Extract JSON from code block if present
    match = re.search(r"```json\n(.*?)\n```", raw_output, re.DOTALL)
    json_text = match.group(1).strip() if match else raw_output

    try:
        meal_plan = json.loads(json_text)
        return meal_plan
    except json.JSONDecodeError:
        return {"error": "Still failed to parse response", "raw_response": raw_output}
