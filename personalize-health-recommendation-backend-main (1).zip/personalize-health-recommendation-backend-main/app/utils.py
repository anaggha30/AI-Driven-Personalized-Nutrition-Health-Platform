def calculate_bmi(weight, height):
    if height == 0:
        return 0
    return weight / (height/100)**2
