from flask import Blueprint, request, jsonify
from app.models import User
from app.database import db
from app import bcrypt
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
import re
import logging

# Setup logger
logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

# Email validation regex
def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

# Password strength check (example: minimum 6 characters)
def is_valid_password(password):
    return len(password) >= 6

# -------------------
# Register Endpoint
# -------------------
@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        logger.info(f"Register attempt with data: {data}")
        print("data while registering", data)
        if not data:
            return jsonify({"msg": "Invalid or missing JSON data"}), 400

        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({"msg": "Email and password are required"}), 400

        if not is_valid_email(email):
            return jsonify({"msg": "Invalid email format"}), 400

        if not is_valid_password(password):
            return jsonify({"msg": "Password must be at least 6 characters"}), 400

        if User.query.filter_by(email=email).first():
            return jsonify({"msg": "User already exists"}), 400

        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(email=email, password=hashed_pw)

        db.session.add(user)
        db.session.commit()

        logger.info(f"User registered successfully: {email}")
        return jsonify({"msg": "User registered successfully"}), 201

    except Exception as e:
        logger.error(f"Register error: {str(e)}")
        return jsonify({"msg": "Something went wrong"}), 500


# -------------------
# Login Endpoint
# -------------------
@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        logger.info(f"Login attempt with data: {data}")

        if not data:
            return jsonify({"msg": "Invalid or missing JSON data"}), 400

        email = data.get('email')
        password = data.get('password')

        if not email or not password:
            return jsonify({"msg": "Email and password are required"}), 400

        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            access_token = create_access_token(identity=str(user.id))

            logger.info(f"Login success for user: {email}")
            
            return jsonify({
                "access_token": access_token,
                "user": {
                    "id": user.id,
                    "email": user.email
                }
            }), 200

        logger.warning(f"Invalid login attempt: {email}")
        return jsonify({"msg": "Invalid credentials"}), 401

    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({"msg": "Something went wrong"}), 500
