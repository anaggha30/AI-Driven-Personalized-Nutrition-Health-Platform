from flask import Blueprint, jsonify
from app.models import HealthProfile
from app.utils.recommendation import generate_meal_plan
from flask_jwt_extended import jwt_required, get_jwt_identity
import logging

meal_bp = Blueprint('meal', __name__)
logger = logging.getLogger(__name__)

@meal_bp.route('/recommend', methods=['GET'])
@jwt_required()
def recommend_meals():
    try:
        user_id = get_jwt_identity()
        logger.info(f"Generating meal plan for user_id: {user_id}")

        profile = HealthProfile.query.filter_by(user_id=user_id).first()

        if not profile:
            logger.warning(f"No health profile found for user_id: {user_id}")
            return jsonify({"msg": "Create health profile first"}), 400

        # Generate meal plan
        meal_plan = generate_meal_plan(profile)

        if not meal_plan:
            logger.warning(f"Meal plan generation returned empty for user_id: {user_id}")
            return jsonify({"msg": "Could not generate meal plan"}), 500

        logger.info(f"Meal plan successfully generated for user_id: {user_id}")
        return jsonify(meal_plan), 200

    except Exception as e:
        logger.exception(f"Error generating meal plan for user_id: {user_id}")
        return jsonify({"msg": f"Error: {str(e)}"}), 500
